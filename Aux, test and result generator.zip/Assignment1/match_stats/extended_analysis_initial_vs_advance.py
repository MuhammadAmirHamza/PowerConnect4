"""In this script we will let agent with initial heuristic and agent with advance heuristicto
play with each other.
    """

from GameBoard import GameBoard
from initial_heuristic_alpha_beta_moveodering import initial_moveordered_alpha_move_beta_action
from advance_heuristic_alpha_beta_moveordering import advance_moveordered_alpha_beta_action
import random 
import time
import sys
import pickle
import os
import matplotlib.pyplot as plt
import numpy as np


def play():
    # initialize game
    game = GameBoard()
    initial_player = 1
    advance_player = 0
    considered_depths = [2, 3, 4]
    wins_of_novice = []
    wins_of_advance = []
    
    for depth in considered_depths: 
        count_novice = 0
        count_advance = 0
        
        for j in range(10):
            print("\n\n\n Game no : ", j + 1)
            print("=======================\n")

            game = GameBoard()
            
            for i in range(70):
                list_actions = game.possible_actions()
                if i == 0:
                    action = random.choice(list_actions)
                    print("Random first action by Noice player : ", action)
                    game.move(action)
                    game.print_grid()
                
                elif i % 2 == initial_player:
                    print('\n\nNoice Player turn:\n================')
                    start = time.time()
                    action, _, _ = initial_moveordered_alpha_move_beta_action(node = game.grid, depth = depth, agent_color=initial_player)
                    stop = time.time()
                    game.move(action)
                    print('Action taken by Noice Player : ', action)
                    print(f'Time taken : {stop - start : .2f} sec')
                    game.print_grid()
                else:
                    print('\n\nAdvance Player turn:\n================')
                    start = time.time()
                    action, _, _ = advance_moveordered_alpha_beta_action(node = game.grid, depth = depth, agent_color=advance_player)
                    stop = time.time()
                    print('Action taken by Advance Player : ', action)
                    print(f'Time taken : {stop - start : .2f} sec')
                    game.move(action)
                    game.print_grid()

                terminal_flag, initial_won_flag, score= game.if_terminal()
                if terminal_flag:
                    if score < 0:
                        print('Novice Player Won')
                        count_novice += 1
                    elif score == 0:
                        print('Draw')
                    else:
                        print('Advance Player Won')
                        count_advance += 1
                    break
        
        wins_of_novice.append(count_novice)
        wins_of_advance.append(count_advance)
    
    print(wins_of_advance, wins_of_novice)
    path1 = os.path.join("match_stats", "Novice_wins.pkl")
    path2 = os.path.join("match_stats", "Advance_wins.pkl")
    with open(path1, 'wb') as file:
        pickle.dump(wins_of_novice, file)
    with open(path2, 'wb') as file:
        pickle.dump(wins_of_advance, file)
    


if __name__ == "__main__":

    # play()
    path2 = os.path.join("match_stats", "Advance_wins.pkl")
    with open(path2, 'rb') as file:
        wins_advance = pickle.load(file)
    print(wins_advance)

    path1 = os.path.join("match_stats", "Novice_wins.pkl")
    with open(path1, 'rb') as file:
        wins_novice = pickle.load(file)
    print(wins_novice)

    # depths
    depths = ("Depth 2", "Depth 3", "Depth 4")
    data = {
        "Advance agent wins" : wins_advance,
        "Novice agent wins" : wins_novice
    }

    x = np.array([2, 3, 4])
    width = 0.25
    multiplier = 0

    fig, ax = plt.subplots(layout = 'constrained')

    for attribute, measurement in data.items():
        offset = width * multiplier
        rects = ax.bar(x+offset, measurement, width, label = attribute)
        ax.bar_label(rects, padding = 3)
        multiplier += 1
    

    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_ylabel('Depth ')
    ax.set_title('Novice vs Advance Agent')
    ax.set_xticks(x , depths)
    ax.legend(loc='upper left', ncols=3)
    ax.set_ylim(0, 12)

    plt.savefig("initial vs advance.png")
    plt.show()

