import socket

class ConnectFourClient:
    def _init_(self, server_host, game_id, color, server_port=12345):
        self.server_host = server_host
        self.server_port = server_port
        self.game_id = game_id
        self.color = color
        self.sock = None

    def connect(self):
        try:
            self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.sock.connect((self.server_host, self.server_port))
            print(f"Connected to {self.server_host} on port {self.server_port}")
            message = f"{self.game_id} {self.color}\n"
            self.send_message(message)
        except Exception as e:
            print(f"Failed to connect: {e}")

    def send_message(self, message):
        try:
            self.sock.sendall(message.encode())
            response = self.sock.recv(64).decode().strip()
            print(f"Sent: {message.strip()}, Received: {response}")
            return response
        except Exception as e:
            print(f"Error sending message: {e}")

    def receive_message(self):
        try:
            response = self.sock.recv(64).decode().strip()
            print(f"Received from server: {response}")
            return response
        except Exception as e:
            print(f"Error receiving message: {e}")
            return None

    def close(self):
        if self.sock:
            self.sock.close()
            print("Connection closed.")


if __name__ == "__main__":
