import pickle
import matplotlib.pyplot as plt
import os
import numpy as np
from matplotlib.ticker import ScalarFormatter

folder = "Result_variables_initial"
path1 = os.path.join(folder, "initial_minimax_depths_3moves1.pkl")
path2 = os.path.join(folder, "initial_minimax_timedata_3moves1.pkl")
path3 = os.path.join(folder, "initial_alpha_beta_depths_3moves.pkl")
path4 = os.path.join(folder, "initial_alpha_beta_timedata_3moves.pkl")
path5 = os.path.join(folder, "initial_minimax_states_3moves1.pkl")
path6 = os.path.join(folder, "initial_alpha_beta_states_3moves.pkl")
path7 = os.path.join(folder, "initial_alpha_beta_moveordering_states_3moves.pkl")
path8 = os.path.join(folder, "initial_alpha_beta_moveordering_depths_3moves.pkl")
# path9 = os.path.join(folder, "advance_heuristic_alpha_beta_states_5moves.pkl")
# path10 = os.path.join(folder, "advance_heuristic_alpha_beta_timedata_5moves.pkl")
# path11 = os.path.join(folder, "advance_heuristic_alpha_beta_moveordering_states_5moves.pkl")
# path12 = os.path.join(folder, "advance_heuristic_alpha_beta_moveordering_timedata_5moves.pkl")

with open(path1, 'rb') as file:
    depths_minimax = pickle.load(file)
with open(path2, 'rb') as file:
    time_data_minimax = pickle.load(file)
with open(path3, 'rb') as file:
    depths_alpha_beta = pickle.load(file)
with open(path4, 'rb') as file:
    time_data_alpha_beta = pickle.load(file)
with open(path5, 'rb') as file:
    states_minimax = pickle.load(file)
with open(path6, 'rb') as file:
    states_alpha_beta = pickle.load(file)
with open(path7, 'rb') as file:
    states_moveordering = pickle.load(file)
with open(path8, 'rb') as file:
    depths_moveordering = pickle.load(file)
# with open(path9, 'rb') as file:
#     states_advance_alpha_beta = pickle.load(file)
# with open(path10, 'rb') as file:
#     time_data_advance_alpha_beta = pickle.load(file)
# with open(path11, 'rb') as file:
#     states_advance_alpha_beta_moveordering = pickle.load(file)
# with open(path12, 'rb') as file:
#     time_data_advance_alpha_beta_moveordering = pickle.load(file)

time_data_minimax = [x / 3 for x in time_data_minimax]
time_data_alpha_beta = [x / 3 for x in time_data_alpha_beta]
plt.figure(1)
plt.plot(depths_minimax[2:], time_data_minimax[2:], marker = 'o', label = 'mimimax' )
plt.plot(depths_alpha_beta[2:], time_data_alpha_beta[2:], marker = 'o', label = r'$\alpha$$\beta$')
plt.xticks(depths_minimax, fontsize = 13)
plt.yticks(fontsize = 13)
plt.xlim(2.8, 6.4)
plt.title(r"Average time taken using Minimax and $\alpha$$\beta$ Pruning")
# annotation
for i in range(2, 6):
    plt.text(depths_alpha_beta[i], time_data_alpha_beta[i], f'{time_data_alpha_beta[i]: .2f}', va = 'top', ha= 'left', fontsize = 10, fontweight = 'bold')
    plt.text(depths_minimax[i], time_data_minimax[i], f'{time_data_minimax[i]: .2f}', va= 'bottom', ha = 'right', fontsize = 10, fontweight = 'bold')
plt.gca().set_xticks(np.arange(3, 7, 1))  # Set x ticks from 0 to 10 with a spacing of 1
# plt.gca().set_yticks(np.arange(0, 2200, 200))
plt.grid(True)
plt.xlabel("Depths")
plt.ylabel("time(sec)")
plt.legend()
plt.savefig("figures_initial/time_comparison_bw_minimax_alphabeta.png", dpi = 600, bbox_inches = 'tight')
plt.show()

"""
plt.figure(2)
plt.plot(depths_minimax[2:], states_minimax[2:], marker = 'o', label = 'minimax' )
plt.plot(depths_alpha_beta[2:], states_alpha_beta[2:], marker = 'o', label = r'$\alpha$$\beta$')
plt.xticks(depths_minimax, fontsize = 13)
plt.yticks(fontsize = 13)
plt.xlim(2.8, 6.4)
plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=True))
plt.title(r"Total states visited in first 3 moves by Minimax and $\alpha$$\beta$ Pruning")
# annotation
for i in range(2, 6):
    plt.text(depths_alpha_beta[i], states_alpha_beta[i], f'{states_alpha_beta[i]}', va = 'top', ha= 'left', fontsize = 10, fontweight = 'bold')
    plt.text(depths_minimax[i], states_minimax[i], f'{states_minimax[i]}', va= 'bottom', ha = 'right', fontsize = 10, fontweight = 'bold')
plt.gca().set_xticks(np.arange(3, 7, 1))  # Set x ticks from 0 to 10 with a spacing of 1
#plt.gca().set_yticks(np.arange(0, 2200, 200))
plt.grid(True)
plt.xlabel("Depths")
plt.ylabel("States")
plt.legend()
plt.savefig("figures_initial/state_comparison_bw_minimax_alphabeta.png", dpi = 600, bbox_inches = 'tight')

# move ordering comparison
plt.figure(3)
plt.plot(depths_alpha_beta[2:], states_alpha_beta[2:], marker = 'o', label = r'$\alpha$$\beta$')
plt.plot(depths_moveordering[2:], states_moveordering[2:], marker = 'o', label = r'move ordered $\alpha$$\beta$')
plt.xticks(depths_minimax, fontsize = 13)
plt.yticks(fontsize = 13)
plt.xlim(2.8, 6.4)
plt.title(r"Total states visited in first 3 moves by $\alpha$$\beta$ with and without move-ordering")
# annotation
for i in range(2, 6):
    plt.text(depths_alpha_beta[i], states_alpha_beta[i], f'{states_alpha_beta[i]}', va = 'bottom', ha= 'left', fontsize = 10, fontweight = 'bold')
    plt.text(depths_moveordering[i], states_moveordering[i], f'{states_moveordering[i]}', va= 'top', ha = 'right', fontsize = 10, fontweight = 'bold')
plt.gca().set_xticks(np.arange(3, 7, 1))  # Set x ticks from 0 to 10 with a spacing of 1
#plt.gca().set_yticks(np.arange(0, 2200, 200))
plt.grid(True)
plt.xlabel("Depths")
plt.ylabel("States")
plt.legend()
plt.savefig("figures_initial/state_comparison_bw_moveordering_and_alphabeta2.png", dpi = 600, bbox_inches = 'tight')


# over all states visited
plt.figure(4)
plt.plot(depths_minimax[2:], states_minimax[2:], marker = 'o', label = 'minimax' )
plt.plot(depths_alpha_beta[2:], states_alpha_beta[2:], marker = 'o', label = r'$\alpha$$\beta$')
plt.plot(depths_moveordering[2:], states_moveordering[2:], marker = 'o', label = r'move ordered $\alpha$$\beta$')
plt.xticks(depths_minimax, fontsize = 13)
plt.yticks(fontsize = 13)
plt.xlim(2.8, 6.4)
plt.title(r"Total states explore in Minimax, $\alpha$$\beta$ and $\alpha$$\beta$ with move ordering")
# annotation
for i in range(2, 6):
    plt.text(depths_alpha_beta[i], states_minimax[i], f'{states_minimax[i]}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
    plt.text(depths_alpha_beta[i], states_alpha_beta[i], f'{states_alpha_beta[i]}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
    plt.text(depths_moveordering[i], states_moveordering[i], f'{states_moveordering[i]}', va= 'bottom', ha = 'left', fontsize = 10, fontweight = 'bold')
plt.legend()
plt.grid(True)
plt.xlabel("Depths")
plt.ylabel("States")
plt.savefig("figures_initial/state_comparison_bw_all.png", dpi = 600, bbox_inches = 'tight')
plt.show()
"""
