"""In this script we will let agent with initial heuristic and agent with advance heuristicto
play with each other.
    """

from GameBoard import GameBoard
from initial_heuristic_alpha_beta_moveodering import initial_moveordered_alpha_move_beta_action
from advance_heuristic_alpha_beta_moveordering import advance_moveordered_alpha_beta_action
import random 
import time
import sys

def play():
    # initialize game
    game = GameBoard()
    initial_player = 1
    advance_player = 0
    
    count_advance = 0
    count_novice = 0
    game = GameBoard()
    terminal_flag = False

    for i in range(70):
        list_actions = game.possible_actions()
        if i == 0:
            action = random.choice(list_actions)
            print("Random first action by white player : ", action)
            game.move(action)
            game.print_grid()
        
        elif i % 2 == initial_player:
            print('\n\nNoice Player turn:\n================')
            start = time.time()
            action, _, _ = initial_moveordered_alpha_move_beta_action(node = game.grid, depth = 4, agent_color=initial_player)
            stop = time.time()
            game.move(action)
            print('Action taken by Novice Player : ', action)
            print(f'Time taken : {stop - start : .2f} sec')
            game.print_grid()
            terminal_flag, initial_won_flag, score = game.if_terminal()

        else:
            print('\n\nAdvance Player turn:\n================')
            start = time.time()
            action, _, _ = advance_moveordered_alpha_beta_action(node = game.grid, depth = 4, agent_color=advance_player)
            stop = time.time()
            print('Action taken by Advance Player : ', action)
            print(f'Time taken : {stop - start : .2f} sec')
            game.move(action)
            game.print_grid()
            terminal_flag, initial_won_flag, score = game.if_terminal()
        if terminal_flag:
            if score < 0:
                print('Novice Player Won')
                count_novice += 1
            elif score == 0:
                print("Draw")
            else:
                print('Advance Player Won')
                count_advance += 1
            break

        # print("Number of times Advance player won : ", count_advance)
        # print("Number of times Novice player won  : ", count_novice)


if __name__ == "__main__":
    # log_file = open("log_file_local.txt", 'w')

    # sys.stdout = log_file

    # play()

    # log_file.close()

    # sys.stdout = sys.__stdout__

    play()