import numpy as np
import matplotlib.pyplot as plt
import os 
import pickle

folder1 = "Result_variables_advance"
folder2 = "Result_variables_initial"
path1 = os.path.join(folder1, 'advance_minimax_depths_3moves.pkl')
path2 = os.path.join(folder1, 'advance_minimax_timedata_3moves.pkl')
path3 = os.path.join(folder2, 'initial_minimax_timedata_3moves1.pkl')
path4 = os.path.join(folder1, 'advance_minimax_states_3moves.pkl')
path5 = os.path.join(folder2, 'initial_minimax_states_3moves1.pkl')
path6 = os.path.join(folder1, 'advance_alpha_beta_states_3moves.pkl')
path7 = os.path.join(folder2, 'initial_alpha_beta_states_3moves.pkl')
path8 = os.path.join(folder1, 'advance_alpha_beta_moveordering_3moves.pkl')
path9 = os.path.join(folder1, 'advance_alpha_beta_timedata_3moves.pkl')
path10 = os.path.join(folder2, 'initial_alpha_beta_timedata_3moves.pkl')

with open(path1, 'rb') as file:
    depths = pickle.load(file)

with open(path2, 'rb') as file:
    advance_minimax_timedata = pickle.load(file)

with open(path3, 'rb') as file:
    initial_minimax_timedata = pickle.load(file)

with open(path4, 'rb') as file:
    advance_minimax_states = pickle.load(file)

with open(path5, 'rb') as file:
    initial_minimax_states = pickle.load(file)

with open(path6, 'rb') as file:
    advance_alpha_beta_states = pickle.load(file)

with open(path7, 'rb') as file:
    initial_alpha_beta_states = pickle.load(file)

with open(path8, 'rb') as file:
    advance_moveordered_states = pickle.load(file)

with open(path9, 'rb') as file:
    advance_alpha_beta_timedata = pickle.load(file)

with open(path10, 'rb') as file:
    initial_alpha_beta_timedata = pickle.load(file)


# plt.figure(1)
# plt.plot(depths[2:], advance_minimax_states[2:], label = 'advance heuristic', marker = 'o')
# plt.plot(depths[2:], initial_minimax_states[2:], label = 'initial hruristic', marker = 'o')
# plt.xticks(depths, fontsize = 13)
# plt.yticks(fontsize = 13)
# plt.xlim(2.8, 6.4)
# plt.title("Total states visited in minimax using initial and modified heuristic for first 3 moves")
# # annotation
# for i in range(2, 6):
#     print(depths[i], advance_minimax_states[i])
#     plt.text(depths[i], advance_minimax_states[i], f'{advance_minimax_states[i]}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
#     plt.text(depths[i], initial_minimax_states[i], f'{initial_minimax_states[i]}', va= 'bottom', ha = 'left', fontsize = 10, fontweight = 'bold')
# plt.grid(True)
# plt.xlabel("Depths")
# plt.ylabel("States")
# plt.legend()
# plt.savefig("figures_advance/state_comparison_bw_minimax_initial_advance.png", dpi = 600, bbox_inches = 'tight')


# plt.figure(2)
# plt.plot(depths[2:], advance_minimax_states[2:], label = 'Minimax', marker = 'o')
# plt.plot(depths[2:], advance_alpha_beta_states[2:], label = r'$\alpha$$\beta$-pruning', marker = 'o')
# plt.xticks(depths, fontsize = 13)
# plt.yticks(fontsize = 13)
# plt.xlim(2.8, 6.4)
# plt.title(r"Total states visited in minimax and $\alpha$$\beta$-pruning using advance heuristic in 3 moves")
# # annotation
# for i in range(2, 6):
#     print(depths[i], advance_minimax_states[i])
#     plt.text(depths[i], advance_minimax_states[i], f'{advance_minimax_states[i]}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
#     plt.text(depths[i], advance_alpha_beta_states[i], f'{advance_alpha_beta_states[i]}', va= 'bottom', ha = 'left', fontsize = 10, fontweight = 'bold')
# plt.grid(True)
# plt.xlabel("Depths")
# plt.ylabel("States")
# plt.legend()
# plt.savefig("figures_advance/state_comparison_minimax_alpha_beta_advance.png", dpi = 600, bbox_inches = 'tight')

# plt.figure(1)
# plt.plot(depths[2:], advance_alpha_beta_states[2:], label = r'$\alpha$$\beta$-pruning', marker = 'o')
# plt.plot(depths[2:], advance_moveordered_states[2:], label = r'$\alpha$$\beta$-pruning with moveordering', marker = 'o')
# plt.xticks(depths, fontsize = 13)
# plt.yticks(fontsize = 13)
# plt.xlim(2.8, 6.4)
# plt.title(r"Total states visited in simple $\alpha$$\beta$-pruning and $\alpha$$\beta$-pruning with moveordering")
# # annotation
# for i in range(2, 6):
#     plt.text(depths[i], advance_moveordered_states[i], f'{advance_moveordered_states[i]}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
#     plt.text(depths[i], advance_alpha_beta_states[i], f'{advance_alpha_beta_states[i]}', va= 'bottom', ha = 'left', fontsize = 10, fontweight = 'bold')
# plt.grid(True)
# plt.xlabel("Depths")
# plt.ylabel("States")
# plt.legend()
# plt.savefig("figures_advance/state_comparison_alpha_beta_moveordered_advance.png", dpi = 600)

# advance_minimax_timedata = [x/3 for x in advance_minimax_timedata]
# initial_minimax_timedata = [x/3 for x in initial_minimax_timedata]

# plt.figure(1)
# plt.plot(depths[2:], advance_minimax_timedata[2:], label = 'Minimax advance heuristic', marker = 'o')
# plt.plot(depths[2:], initial_minimax_timedata[2:], label = 'Minimax initial heuristic', marker = 'o')
# plt.xticks(depths, fontsize = 13)
# plt.yticks(fontsize = 13)
# plt.xlim(2.8, 6.4)
# plt.title("Average time taken by Minimax using initial and advance heuristic")
# # annotation
# for i in range(2, 6):
#     plt.text(depths[i], advance_minimax_timedata[i], f'{advance_minimax_timedata[i]:.1f}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
#     plt.text(depths[i], initial_minimax_timedata[i], f'{initial_minimax_timedata[i]:.1f}', va= 'top', ha = 'left', fontsize = 10, fontweight = 'bold')
# plt.grid(True)
# plt.xlabel("Depths")
# plt.ylabel("Time(sec)")
# plt.legend()
# plt.savefig("figures_advance/time_comparison_minimax_initial_advance.png", dpi = 600)

advance_alpha_beta_timedata = [x / 3 for x in advance_alpha_beta_timedata]
initial_alpha_beta_timedata = [x/3 for x in initial_alpha_beta_timedata]
plt.figure(1)
plt.plot(depths[2:], advance_alpha_beta_timedata[2:], label = r'$\alpha \beta$ advance heuristic', marker = 'o')
plt.plot(depths[2:], initial_alpha_beta_timedata[2:], label = r'$\alpha \beta$ initial heuristic', marker = 'o')
plt.xticks(depths, fontsize = 13)
plt.yticks(fontsize = 13)
plt.xlim(2.8, 6.4)
plt.title(r"Average time taken per move by $\alpha \beta$ using initial and advance heuristic")
# annotation
for i in range(2, 6):
    plt.text(depths[i], advance_alpha_beta_timedata[i], f'{advance_alpha_beta_timedata[i]:.1f}', va = 'top', ha= 'right', fontsize = 10, fontweight = 'bold')
    plt.text(depths[i], initial_alpha_beta_timedata[i], f'{initial_alpha_beta_timedata[i]:.1f}', va= 'top', ha = 'left', fontsize = 10, fontweight = 'bold')
plt.grid(True)
plt.xlabel("Depths")
plt.ylabel("Time(sec)")
plt.legend()
plt.savefig("figures_advance/time_comparison_alpha_beta_initial_advance.png", dpi = 600)


# plt.figure(1)
# plt.plot
# plt.figure(2)
# plt.plot(depths, advance_minimax_states)
# plt.plot(depths, initial_minimax_states)

# plt.figure(3)
# plt.plot(depths, advance_alpha_beta_states)
# plt.plot(depths, initial_alpha_beta_states)

plt.show()